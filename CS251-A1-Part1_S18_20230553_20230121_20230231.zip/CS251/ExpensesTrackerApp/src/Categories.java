
/// Enum for categories 
public enum Categories {
    Food,
    Transport,
    Entertainment,
    Shopping,
    Bills,
    Others,
}
