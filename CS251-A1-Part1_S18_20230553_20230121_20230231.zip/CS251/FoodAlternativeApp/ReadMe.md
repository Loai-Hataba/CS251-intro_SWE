HEllo

Instructions to use the Food Alternative app:

1.  Make sure the directory structure is maintained as in the zip folder
2.  In you're java project settings add:
    a) in the sources path add the path to the foodAlternativeApp folder
    b) in the libraries add the path to the file "gson-2.10.1.jar" located in the libs folder
    3
3.  You can run the program through your IDE like you normally would
    Note: if you run into any problems regarding compiling you may want to instead use the run.sh file located in the project it will handle the compilation and running of the program

    in your git bash terminal make sure you're in the foodAlternativeApp directory and just run the command

                                                                                 command-> ./run
