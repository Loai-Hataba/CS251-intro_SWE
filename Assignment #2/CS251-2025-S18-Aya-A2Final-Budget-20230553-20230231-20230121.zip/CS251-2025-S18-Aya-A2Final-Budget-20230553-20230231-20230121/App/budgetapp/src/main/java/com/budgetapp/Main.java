package com.budgetapp;

import com.budgetapp.system.UI;

public class Main {
    public static void main(String[] args) {
        UI myUI = new UI();
        myUI.UImanager();
    }
}